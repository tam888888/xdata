const fs = require("fs");
let ex = ['hose', 'hnx', 'upcom']
let f = async (e) => {
    q = await fetch("https://iboard-query.ssi.com.vn/v2/stock/exchange/" + e, {
        "headers": {
            "accept": "application/json, text/plain, */*",
            "accept-language": "vi",
            "cache-control": "no-cache",
            "device-id": "1CB43CB4-03AE-4855-81AD-734F433F10D4",
            "pragma": "no-cache",
            "sec-ch-ua": "\"Not/A)Brand\";v=\"99\", \"Google Chrome\";v=\"115\", \"Chromium\";v=\"115\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "Referer": "https://iboard.ssi.com.vn/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        },
        "body": null,
        "method": "GET"
    });
   
    r = await q.json()
    // console.log(r)
    return r.data
}

(async () => {
    let data = [...await f('hose'), ...await f('hnx'), ...await f('upcom')];
    let mapX = {};
    data.forEach(e => { mapX[e.ss] = e.sn });
    console.log("Done get symbols", Object.keys(mapX).length)
    fs.writeFileSync('symbols.json',JSON.stringify(mapX))
})();